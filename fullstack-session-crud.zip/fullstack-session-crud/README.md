# Fullstack Session CRUD Starter

This starter includes:
- `frontend-angular`: Angular app for login + CRUD UI
- `backend-nextjs`: Next.js API with Redis session storage and PostgreSQL CRUD
- Local infra via Docker Compose (`postgres`, `redis`)
- Environment templates for local and staging
- Ubuntu setup and AWS staging deployment guide

## Architecture

- Frontend calls backend REST APIs.
- Backend stores users in PostgreSQL.
- Backend stores session data in Redis (`sess:<sessionId>` keys).
- Cookie-based session (`sid`) is set by backend.

## Project Structure

- `frontend-angular/` Angular standalone app
- `backend-nextjs/` Next.js app-router API backend
- `infra/docker-compose.local.yml` Local PostgreSQL + Redis
- `infra/sql/init.sql` DB schema initialization
- `scripts/ubuntu-setup.sh` Ubuntu dependencies installer
- `deployment/aws-staging/README.md` AWS staging deployment steps

## Quick Start (Local)

1) Start PostgreSQL + Redis:

```bash
cd infra
docker compose -f docker-compose.local.yml --env-file .env.local up -d
```

2) Start backend:

```bash
cd ../backend-nextjs
cp .env.local.example .env.local
npm install
npm run dev
```

3) Start frontend:

```bash
cd ../frontend-angular
npm install
npm run start
```

4) Open:
- Frontend: `http://localhost:4200`
- Backend health: `http://localhost:3000/api/health`

## API Endpoints

- `POST /api/auth/login` body: `{ "email": "admin@example.com" }`
- `POST /api/auth/logout`
- `GET /api/session`
- `GET /api/users`
- `POST /api/users`
- `GET /api/users/:id`
- `PUT /api/users/:id`
- `DELETE /api/users/:id`

All `/api/users*` endpoints require an active session.

## Environment Files

- Backend local: `backend-nextjs/.env.local`
- Backend staging template: `backend-nextjs/.env.staging.example`
- Infra local: `infra/.env.local`
- Frontend local env: `frontend-angular/src/environments/environment.ts`
- Frontend staging env: `frontend-angular/src/environments/environment.staging.ts`

## Local Test Flow

1) Login from UI with any email.
2) Create user.
3) Edit user.
4) Delete user.
5) Refresh page and verify session still active.
6) Logout and verify CRUD calls fail with `401`.

## Notes

- For production/staging, use managed `RDS PostgreSQL` and `ElastiCache Redis`.
- Set secure cookie + HTTPS in staging and production.
