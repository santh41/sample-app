# Fullstack Session CRUD Starter

This starter includes:
- `frontend-angular`: Angular app for login + CRUD UI
- `backend-nextjs`: Next.js API with Redis session storage and PostgreSQL CRUD
- Local infra via Docker Compose (`postgres`, `redis`) or your own local installs
- Environment templates for local and staging
- Ubuntu setup and AWS staging deployment guide

## Architecture

- Frontend calls backend REST APIs.
- Backend stores users in PostgreSQL.
- Backend stores session data in Redis (`sess:<sessionId>` keys).
- Cookie-based session (`sid`) is set by backend.

## Project Structure

- `frontend-angular/` Angular standalone app
- `backend-nextjs/` Next.js app-router API backend
- `infra/docker-compose.local.yml` Local PostgreSQL + Redis
- `infra/sql/init.sql` DB schema initialization
- `scripts/ubuntu-setup.sh` Ubuntu dependencies installer
- `deployment/aws-staging/README.md` AWS staging deployment steps

## Quick Start (Local)

You can use either:
- Option A: Docker Compose from `infra/`
- Option B: already-installed localhost PostgreSQL + Redis

### Option A: Docker local infra

1) Start PostgreSQL + Redis:

```bash
cd infra
docker compose -f docker-compose.local.yml --env-file .env.local up -d
```

2) Start backend:

```bash
cd ../backend-nextjs
cp .env.local.example .env.local
npm install
npm run dev
```

3) Start frontend:

```bash
cd ../frontend-angular
npm install
npm run start
```

4) Open:
- Frontend: `http://localhost:4200`
- Backend health: `http://localhost:3000/api/health`

### Option B: Localhost PostgreSQL + Redis (your setup)

1) Ensure services are running:
- PostgreSQL on `localhost:5432`
- Redis on `localhost:6379`

Quick Redis check:

```bash
redis-cli ping
```

Expected output: `PONG`

2) Create database:

On Ubuntu, the most reliable way is to use the OS `postgres` user (peer authentication), which avoids password prompts:

```bash
sudo -u postgres psql -c "CREATE DATABASE appdb;"
```

If you prefer TCP auth with password prompts, you can also use:

```bash
psql -U postgres -h localhost -c "CREATE DATABASE appdb;"
```

3) Initialize schema:

```bash
sudo -u postgres psql -d appdb -f infra/sql/init.sql
```

Or TCP:

```bash
psql -U postgres -h localhost -d appdb -f infra/sql/init.sql
```

Notes:
- If you see `NOTICE: trigger ... does not exist, skipping` during `init.sql`, that is normal on a fresh database.
- `init.sql` creates the `users` table and an `updated_at` trigger.

4) Verify schema (optional):

```bash
sudo -u postgres psql -d appdb -c "\dt"
sudo -u postgres psql -d appdb -c "\d users"
```

5) Backend env:

`backend-nextjs/.env.local` is already added. Update `DATABASE_URL` if your username/password/database differ.

Format:

```text
postgresql://<user>:<password>@localhost:5432/<database>
```

6) Run backend with host/port bind:

```bash
cd backend-nextjs
npm install
npm run build
npm start
```

or dev mode:

```bash
npm run dev
```

7) Run frontend:

```bash
cd ../frontend-angular
npm install
npm run start
```

#### PostgreSQL troubleshooting (Ubuntu)

If `psql -U postgres -h localhost` fails with password errors, reset the DB password using peer auth:

```bash
sudo -u postgres psql
```

Then:

```sql
ALTER USER postgres WITH PASSWORD 'postgres';
\q
```

If `sudo -u postgres psql` does not work on your machine, temporarily switch `pg_hba.conf` to `trust` for localhost, restart PostgreSQL, reset password, then revert `pg_hba.conf` back to `scram-sha-256` (or `md5`) and restart again.

## API Endpoints

- `POST /api/auth/login` body: `{ "email": "admin@example.com" }`
- `POST /api/auth/logout`
- `GET /api/session`
- `GET /api/users`
- `POST /api/users`
- `GET /api/users/:id`
- `PUT /api/users/:id`
- `DELETE /api/users/:id`

All `/api/users*` endpoints require an active session.

## Environment Files

- Backend local: `backend-nextjs/.env.local`
- Backend staging template: `backend-nextjs/.env.staging.example`
- Infra local: `infra/.env.local`
- Frontend local env: `frontend-angular/src/environments/environment.ts`
- Frontend staging env: `frontend-angular/src/environments/environment.staging.ts`

## Local Test Flow

1) Login from UI with any email.
2) Create user.
3) Edit user.
4) Delete user.
5) Refresh page and verify session still active.
6) Logout and verify CRUD calls fail with `401`.

## Notes

- For production/staging, use managed `RDS PostgreSQL` and `ElastiCache Redis`.
- Set secure cookie + HTTPS in staging and production.
