import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { environment } from "../environments/environment";

export interface User {
  id: string;
  name: string;
  email: string;
  created_at: string;
  updated_at: string;
}

@Injectable({ providedIn: "root" })
export class ApiService {
  private readonly baseUrl = environment.apiBaseUrl;

  constructor(private readonly http: HttpClient) {}

  login(email: string): Observable<unknown> {
    return this.http.post(
      `${this.baseUrl}/api/auth/login`,
      { email },
      { withCredentials: true }
    );
  }

  logout(): Observable<unknown> {
    return this.http.post(`${this.baseUrl}/api/auth/logout`, {}, { withCredentials: true });
  }

  session(): Observable<unknown> {
    return this.http.get(`${this.baseUrl}/api/session`, { withCredentials: true });
  }

  listUsers(): Observable<{ ok: boolean; data: User[] }> {
    return this.http.get<{ ok: boolean; data: User[] }>(`${this.baseUrl}/api/users`, {
      withCredentials: true
    });
  }

  createUser(name: string, email: string): Observable<unknown> {
    return this.http.post(
      `${this.baseUrl}/api/users`,
      { name, email },
      { withCredentials: true }
    );
  }

  updateUser(id: string, name: string, email: string): Observable<unknown> {
    return this.http.put(
      `${this.baseUrl}/api/users/${id}`,
      { name, email },
      { withCredentials: true }
    );
  }

  deleteUser(id: string): Observable<unknown> {
    return this.http.delete(`${this.baseUrl}/api/users/${id}`, { withCredentials: true });
  }
}
