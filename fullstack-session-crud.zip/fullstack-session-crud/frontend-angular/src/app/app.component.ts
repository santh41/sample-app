import { CommonModule } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ApiService, User } from "./api.service";

@Component({
  selector: "app-root",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./app.component.html"
})
export class AppComponent implements OnInit {
  loginEmail = "admin@example.com";
  userName = "";
  userEmail = "";
  editingId: string | null = null;
  users: User[] = [];
  error = "";
  message = "";
  sessionEmail = "";

  constructor(private readonly api: ApiService) {}

  ngOnInit(): void {
    this.refreshSession();
  }

  refreshSession(): void {
    this.api.session().subscribe({
      next: (res: any) => {
        this.sessionEmail = res?.session?.email ?? "";
        this.error = "";
        this.loadUsers();
      },
      error: () => {
        this.sessionEmail = "";
        this.users = [];
      }
    });
  }

  login(): void {
    this.api.login(this.loginEmail).subscribe({
      next: () => {
        this.message = "Logged in successfully";
        this.error = "";
        this.refreshSession();
      },
      error: (err) => {
        this.error = err?.error?.message ?? "Login failed";
      }
    });
  }

  logout(): void {
    this.api.logout().subscribe({
      next: () => {
        this.message = "Logged out";
        this.sessionEmail = "";
        this.users = [];
      },
      error: () => {
        this.error = "Logout failed";
      }
    });
  }

  loadUsers(): void {
    this.api.listUsers().subscribe({
      next: (res) => {
        this.users = res.data ?? [];
      },
      error: (err) => {
        this.error = err?.error?.message ?? "Failed to load users";
      }
    });
  }

  saveUser(): void {
    if (!this.userName.trim() || !this.userEmail.trim()) {
      this.error = "Name and email are required";
      return;
    }

    const request$ = this.editingId
      ? this.api.updateUser(this.editingId, this.userName, this.userEmail)
      : this.api.createUser(this.userName, this.userEmail);

    request$.subscribe({
      next: () => {
        this.message = this.editingId ? "User updated" : "User created";
        this.error = "";
        this.cancelEdit();
        this.loadUsers();
      },
      error: (err) => {
        this.error = err?.error?.message ?? "Failed to save user";
      }
    });
  }

  editUser(user: User): void {
    this.editingId = user.id;
    this.userName = user.name;
    this.userEmail = user.email;
  }

  cancelEdit(): void {
    this.editingId = null;
    this.userName = "";
    this.userEmail = "";
  }

  removeUser(id: string): void {
    this.api.deleteUser(id).subscribe({
      next: () => {
        this.message = "User deleted";
        this.error = "";
        this.loadUsers();
      },
      error: (err) => {
        this.error = err?.error?.message ?? "Delete failed";
      }
    });
  }
}
