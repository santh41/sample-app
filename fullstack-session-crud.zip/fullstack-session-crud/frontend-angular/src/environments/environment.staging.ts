export const environment = {
  production: true,
  apiBaseUrl: "https://api-staging.example.com"
};
