import { NextResponse } from "next/server";
import { z } from "zod";
import { requireSession } from "@/lib/auth-guard";
import { createUser, listUsers } from "@/lib/users-repository";

const createUserSchema = z.object({
  name: z.string().min(2),
  email: z.string().email()
});

export async function GET() {
  const auth = await requireSession();
  if (auth.unauthorized) {
    return auth.unauthorized;
  }

  try {
    const users = await listUsers();
    return NextResponse.json({ ok: true, session: auth.session, data: users });
  } catch {
    return NextResponse.json({ ok: false, message: "Failed to list users" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const auth = await requireSession();
  if (auth.unauthorized) {
    return auth.unauthorized;
  }

  try {
    const body = await request.json();
    const payload = createUserSchema.parse(body);
    const user = await createUser(payload.name, payload.email);
    return NextResponse.json({ ok: true, session: auth.session, data: user }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { ok: false, message: "Invalid user payload", details: error.flatten() },
        { status: 400 }
      );
    }
    return NextResponse.json({ ok: false, message: "Failed to create user" }, { status: 500 });
  }
}
