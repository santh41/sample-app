import { NextResponse } from "next/server";
import { z } from "zod";
import { requireSession } from "@/lib/auth-guard";
import { deleteUser, getUserById, updateUser } from "@/lib/users-repository";

const idSchema = z.string().uuid();

const updateUserSchema = z.object({
  name: z.string().min(2),
  email: z.string().email()
});

interface Context {
  params: { id: string };
}

export async function GET(_: Request, context: Context) {
  const auth = await requireSession();
  if (auth.unauthorized) {
    return auth.unauthorized;
  }

  try {
    const id = idSchema.parse(context.params.id);
    const user = await getUserById(id);
    if (!user) {
      return NextResponse.json({ ok: false, message: "User not found" }, { status: 404 });
    }
    return NextResponse.json({ ok: true, session: auth.session, data: user });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ ok: false, message: "Invalid user id" }, { status: 400 });
    }
    return NextResponse.json({ ok: false, message: "Failed to fetch user" }, { status: 500 });
  }
}

export async function PUT(request: Request, context: Context) {
  const auth = await requireSession();
  if (auth.unauthorized) {
    return auth.unauthorized;
  }

  try {
    const id = idSchema.parse(context.params.id);
    const body = await request.json();
    const payload = updateUserSchema.parse(body);
    const user = await updateUser(id, payload.name, payload.email);
    if (!user) {
      return NextResponse.json({ ok: false, message: "User not found" }, { status: 404 });
    }
    return NextResponse.json({ ok: true, session: auth.session, data: user });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { ok: false, message: "Invalid update payload", details: error.flatten() },
        { status: 400 }
      );
    }
    return NextResponse.json({ ok: false, message: "Failed to update user" }, { status: 500 });
  }
}

export async function DELETE(_: Request, context: Context) {
  const auth = await requireSession();
  if (auth.unauthorized) {
    return auth.unauthorized;
  }

  try {
    const id = idSchema.parse(context.params.id);
    const removed = await deleteUser(id);
    if (!removed) {
      return NextResponse.json({ ok: false, message: "User not found" }, { status: 404 });
    }
    return NextResponse.json({ ok: true, session: auth.session });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ ok: false, message: "Invalid user id" }, { status: 400 });
    }
    return NextResponse.json({ ok: false, message: "Failed to delete user" }, { status: 500 });
  }
}
