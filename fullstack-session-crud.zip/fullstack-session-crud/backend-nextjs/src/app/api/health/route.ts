import { NextResponse } from "next/server";
import { pgPool } from "@/lib/db";
import { redis } from "@/lib/redis";

export async function GET() {
  try {
    await pgPool.query("SELECT 1");
    await redis.ping();
    return NextResponse.json({ ok: true, service: "backend-nextjs" });
  } catch (error) {
    return NextResponse.json(
      { ok: false, message: "Dependency health check failed", error: String(error) },
      { status: 500 }
    );
  }
}
