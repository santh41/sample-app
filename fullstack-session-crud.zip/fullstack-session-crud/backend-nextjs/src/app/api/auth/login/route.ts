import { NextResponse } from "next/server";
import { z } from "zod";
import { createSession } from "@/lib/session";

const loginSchema = z.object({
  email: z.string().email()
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const payload = loginSchema.parse(body);
    const session = await createSession(payload.email);
    return NextResponse.json({ ok: true, session });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { ok: false, message: "Invalid login payload", details: error.flatten() },
        { status: 400 }
      );
    }
    return NextResponse.json({ ok: false, message: "Login failed" }, { status: 500 });
  }
}
