export default function HomePage() {
  return (
    <main style={{ fontFamily: "Arial, sans-serif", padding: "2rem" }}>
      <h1>Next.js Backend API</h1>
      <p>Use the API routes from your frontend app.</p>
      <ul>
        <li>/api/health</li>
        <li>/api/auth/login</li>
        <li>/api/auth/logout</li>
        <li>/api/session</li>
        <li>/api/users</li>
      </ul>
    </main>
  );
}
