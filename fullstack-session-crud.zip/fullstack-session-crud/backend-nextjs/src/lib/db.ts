import { Pool } from "pg";

const globalForPg = globalThis as unknown as { pgPool?: Pool };

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

export const pgPool =
  globalForPg.pgPool ??
  new Pool({
    connectionString: databaseUrl
  });

if (process.env.NODE_ENV !== "production") {
  globalForPg.pgPool = pgPool;
}
