import { pgPool } from "@/lib/db";

export interface UserRecord {
  id: string;
  name: string;
  email: string;
  created_at: string;
  updated_at: string;
}

export async function listUsers(): Promise<UserRecord[]> {
  const result = await pgPool.query<UserRecord>(
    "SELECT id, name, email, created_at, updated_at FROM users ORDER BY created_at DESC"
  );
  return result.rows;
}

export async function getUserById(id: string): Promise<UserRecord | null> {
  const result = await pgPool.query<UserRecord>(
    "SELECT id, name, email, created_at, updated_at FROM users WHERE id = $1",
    [id]
  );
  return result.rows[0] ?? null;
}

export async function createUser(name: string, email: string): Promise<UserRecord> {
  const result = await pgPool.query<UserRecord>(
    "INSERT INTO users (name, email) VALUES ($1, $2) RETURNING id, name, email, created_at, updated_at",
    [name, email]
  );
  return result.rows[0];
}

export async function updateUser(id: string, name: string, email: string): Promise<UserRecord | null> {
  const result = await pgPool.query<UserRecord>(
    "UPDATE users SET name = $2, email = $3 WHERE id = $1 RETURNING id, name, email, created_at, updated_at",
    [id, name, email]
  );
  return result.rows[0] ?? null;
}

export async function deleteUser(id: string): Promise<boolean> {
  const result = await pgPool.query("DELETE FROM users WHERE id = $1", [id]);
  return (result.rowCount ?? 0) > 0;
}
