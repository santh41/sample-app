import { NextResponse } from "next/server";
import { getSession, type SessionData } from "@/lib/session";

export async function requireSession(): Promise<
  { session: SessionData; unauthorized?: undefined } | { session?: undefined; unauthorized: NextResponse }
> {
  const session = await getSession();
  if (!session) {
    return {
      unauthorized: NextResponse.json({ ok: false, message: "Unauthorized" }, { status: 401 })
    };
  }
  return { session };
}
