import { cookies } from "next/headers";
import { randomUUID } from "node:crypto";
import { redis } from "@/lib/redis";

const SESSION_COOKIE_NAME = process.env.SESSION_COOKIE_NAME ?? "sid";
const SESSION_TTL_SECONDS = Number(process.env.SESSION_TTL_SECONDS ?? "86400");

export interface SessionData {
  sessionId: string;
  email: string;
}

function redisSessionKey(sessionId: string): string {
  return `sess:${sessionId}`;
}

export async function createSession(email: string): Promise<SessionData> {
  const sessionId = randomUUID();
  const key = redisSessionKey(sessionId);
  await redis.hset(key, { email });
  await redis.expire(key, SESSION_TTL_SECONDS);

  const cookieStore = cookies();
  cookieStore.set(SESSION_COOKIE_NAME, sessionId, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_TTL_SECONDS
  });

  return { sessionId, email };
}

export async function getSession(): Promise<SessionData | null> {
  const cookieStore = cookies();
  const sessionId = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  if (!sessionId) {
    return null;
  }

  const email = await redis.hget(redisSessionKey(sessionId), "email");
  if (!email) {
    return null;
  }

  await redis.expire(redisSessionKey(sessionId), SESSION_TTL_SECONDS);
  return { sessionId, email };
}

export async function destroySession(): Promise<void> {
  const cookieStore = cookies();
  const sessionId = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  if (sessionId) {
    await redis.del(redisSessionKey(sessionId));
  }
  cookieStore.delete(SESSION_COOKIE_NAME);
}
