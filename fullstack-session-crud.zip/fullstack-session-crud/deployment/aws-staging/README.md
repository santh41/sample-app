# AWS Staging Deployment (Ubuntu + CLI)

This guide deploys:
- Angular frontend to `S3 + CloudFront`
- Next.js backend to `ECS Fargate`
- Database on `RDS PostgreSQL`
- Session storage on `ElastiCache Redis`

## 1) Install tools on Ubuntu

```bash
sudo apt update
sudo apt install -y unzip curl jq
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o awscliv2.zip
unzip awscliv2.zip
sudo ./aws/install
aws --version
```

Install Docker and Node.js from `scripts/ubuntu-setup.sh`.

## 2) Configure AWS credentials

```bash
aws configure
```

Provide:
- AWS Access Key
- AWS Secret Key
- Region (example: `ap-south-1`)
- Output format (`json`)

## 3) Create staging resources (high level)

1. Create VPC/subnets/security groups.
2. Create RDS PostgreSQL instance.
3. Create ElastiCache Redis cluster.
4. Create ECR repositories:
   - `staging-backend-nextjs`
5. Create ECS cluster + task definition + service.
6. Create S3 bucket + CloudFront distribution for Angular static files.

## 4) Backend environment variables (ECS task)

Set these in ECS task definition:

- `DATABASE_URL=postgresql://<user>:<password>@<rds-endpoint>:5432/<db>`
- `REDIS_URL=redis://<elasticache-endpoint>:6379`
- `SESSION_COOKIE_NAME=sid`
- `SESSION_TTL_SECONDS=86400`
- `NODE_ENV=production`

## 5) Build and push backend image

From `backend-nextjs/`:

```bash
aws ecr get-login-password --region <region> | docker login --username AWS --password-stdin <account-id>.dkr.ecr.<region>.amazonaws.com
docker build -t staging-backend-nextjs .
docker tag staging-backend-nextjs:latest <account-id>.dkr.ecr.<region>.amazonaws.com/staging-backend-nextjs:latest
docker push <account-id>.dkr.ecr.<region>.amazonaws.com/staging-backend-nextjs:latest
```

Then update ECS service to new image revision.

## 6) Build and deploy frontend to S3

Update `frontend-angular/src/environments/environment.staging.ts`:
- `apiBaseUrl` => your backend public URL

Build and upload:

```bash
cd frontend-angular
npm install
npm run build:staging
aws s3 sync dist/frontend-angular/browser s3://<your-staging-bucket> --delete
```

If CloudFront is configured:

```bash
aws cloudfront create-invalidation --distribution-id <distribution-id> --paths "/*"
```

## 7) CORS and cookies

Backend must allow frontend origin and credentials in staging via reverse proxy (ALB/API gateway) configuration.
Always use HTTPS in staging so secure cookies work properly.

## 8) Staging validation checklist

- Health endpoint returns `ok: true`
- Login works and session cookie is set
- Create, Read, Update, Delete user flows work
- Refresh page keeps session active
- Logout clears session and blocks CRUD calls with `401`
