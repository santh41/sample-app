#!/usr/bin/env bash
set -euo pipefail

echo "Updating apt packages..."
sudo apt update

echo "Installing base dependencies..."
sudo apt install -y curl git build-essential ca-certificates gnupg lsb-release

echo "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

echo "Installing Docker..."
sudo apt install -y docker.io docker-compose-plugin
sudo usermod -aG docker "$USER"

echo "Node version:"
node -v
echo "NPM version:"
npm -v
echo "Docker version:"
docker --version

echo "Setup complete. Log out and log in again to apply Docker group changes."
